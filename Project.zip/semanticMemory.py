# semanticMemory.py
#**************************************************************************************************
#   SemanticMemory,py works by storing and retrieving AutoCAD drawing descriptions. It uses ChromaDB
#   for vector storage and retrieval based on text embeddings. It also provides functions to add, remove,
#   list, and search drawings in the database.
#**************************************************************************************************
import io
from contextlib import redirect_stdout
import os
import json
from typing import Dict, List, Optional

import chromadb
from chromadb.utils import embedding_functions
from colorama import Fore, Style
import logging
logging.getLogger("chromadb").setLevel(logging.ERROR)

PERSIST_DIRECTORY = os.path.join(os.path.dirname(__file__), "chroma_persist")
client = chromadb.PersistentClient(path=PERSIST_DIRECTORY)

default_ef = embedding_functions.DefaultEmbeddingFunction()

COLLECTION_NAME = "autocad_drawings"
collection = client.get_or_create_collection(
    name=COLLECTION_NAME,
    embedding_function=default_ef
)

def generate_embedding_id(pdf_path: str) -> str:
    """Generate a unique ID based on the file path."""
    return str(hash(pdf_path))

def add_to_database(pdf_path: str, description: str, specs: Dict, silent: bool = False) -> bool:
    """
    Add or update a file in the ChromaDB collection.
    Removes duplicates based on filename before adding.
    """
    try:
        filename = os.path.basename(pdf_path)
        embedding_id = generate_embedding_id(pdf_path)

        existing = collection.get(ids=[embedding_id])
        if existing and existing['ids']:
            with io.StringIO() as buf, redirect_stdout(buf):
                collection.delete(ids=[embedding_id])
            if not silent:
                print(Fore.YELLOW + f"[!] Replacing existing entry: {filename}" + Style.RESET_ALL)

        metadata = {
            "filename": filename,
            "filepath": os.path.abspath(pdf_path),
            "description": description,
            "specs": json.dumps(specs) if specs else "{}"
        }

        collection.add(
            ids=[embedding_id],
            documents=[description],
            metadatas=[metadata]
        )

        if not silent:
            print(Fore.GREEN + f"Added: {filename}" + Style.RESET_ALL)
        return True

    except Exception as e:
        if not silent:
            print(Fore.RED + f"Error adding {filename}: {e}" + Style.RESET_ALL)
        return False

def get_from_database(filename: str) -> Optional[Dict]:
    """
    Retrieve a single file's data from the database.
    """
    try:
        embedding_id = generate_embedding_id(filename)
        results = collection.get(ids=[embedding_id])

        if results and results["ids"]:
            meta = results["metadatas"][0] if results["metadatas"] else {}
            return {
                "filename": meta.get("filename", os.path.basename(filename)),
                "filepath": meta.get("filepath", filename),
                "description": results["documents"][0],
                "specs": json.loads(meta.get("specs", "{}"))
            }
    except Exception as e:
        print(Fore.RED + f"Error retrieving {filename}: {e}" + Style.RESET_ALL)

    return None

def file_exists_in_database(pdf_path: str) -> bool:
    """
    Check if a file exists in the database by its ID.
    """
    embedding_id = generate_embedding_id(pdf_path)
    try:
        results = collection.get(ids=[embedding_id])
        return bool(results and results["ids"])
    except Exception:
        return False

def list_database_files() -> List[tuple]:
    """
    List all files in the database.
    Returns (filepath, description, specs_json), but only file names will be displayed in UI.
    """
    try:
        if collection.count() == 0:
            return []

        results = collection.get(include=["metadatas", "documents"])
        ids = results.get("ids", [])
        metadatas = results.get("metadatas", [])
        documents = results.get("documents", [])

        output = []
        for i in range(len(ids)):
            if i >= len(metadatas):
                continue
            meta = metadatas[i]
            filepath = meta.get("filepath", meta.get("filename", ids[i]))
            description = documents[i] if i < len(documents) else ""
            specs_json = meta.get("specs", "{}")
            output.append((filepath, description, specs_json))

        return output

    except Exception as e:
        print(Fore.RED + f"Error listing database: {e}" + Style.RESET_ALL)
        return []

def remove_from_database(filename: str) -> bool:
    """
    Remove a file from the database by its filename.
    """
    try:
        embedding_id = generate_embedding_id(filename)
        collection.delete(ids=[embedding_id])
        print(Fore.GREEN + f"Removed: {os.path.basename(filename)}" + Style.RESET_ALL)
        return True
    except Exception as e:
        print(Fore.RED + f"Error removing {os.path.basename(filename)}: {e}" + Style.RESET_ALL)
        return False

def search_similar_files(query: str, n_results: int = 5) -> List[Dict]:
    """
    Search ChromaDB for similar drawings.
    """
    try:
        results = collection.query(query_texts=[query], n_results=n_results)
        matches = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]

        if not matches:
            print(Fore.YELLOW + "No similar files found." + Style.RESET_ALL)
            return []

        print(Fore.CYAN + f"\nTop {len(matches)} matches for '{query}':" + Style.RESET_ALL)

        results_list = []
        for i, (fid, desc, meta) in enumerate(zip(matches, docs, metas), 1):
            display_name = meta.get("filename", os.path.basename(meta.get("filepath", fid)))
            filepath = meta.get("filepath", fid)
            print(f"{i}) {display_name}")
            print(f"   {desc[:120]}...")
            results_list.append({
                "filename": display_name,
                "filepath": filepath,
                "description": desc
            })

        return results_list

    except Exception as e:
        print(Fore.RED + f"Error during search: {e}" + Style.RESET_ALL)
        return []


def get_database_stats() -> Dict[str, int]:
    """
    Get database statistics.
    """
    try:
        results = collection.get()
        return {"total_files": len(results.get("ids", []))}
    except Exception:
        return {"total_files": 0}